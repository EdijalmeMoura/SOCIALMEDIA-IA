# SocialMedia IA — versão PHP

Port do produto para **PHP 8.0+ puro**, pensado para hospedagem compartilhada
(cPanel): sobe os arquivos e funciona. Sem Composer, sem Node, sem Passenger.

> Estado atual: **base funcional + clientes + planejamento + estúdio +
> aprovações + feed + relatórios** —
> instalador de 3 telas, login, dashboard, banco SQLite, sessão/CSRF, tratamento
> de subpasta, portfólio de clientes (perfil, identidade visual, logo e
> referências), calendário editorial com IA, criação de artes com prancheta,
> histórico de versões e exportação, revisão pelo cliente em portal próprio com
> histórico e ciclos, a prévia do feed montada a partir do que já foi
> produzido e o relatório operacional com exportação em CSV. Falta só o módulo
> Meta (conexões e publicação), que entra reaproveitando esta mesma base e o
> mesmo esquema de dados.

## Baixar o pacote pronto

`downloads/SOCIALMEDIA-IA-php-v1.6.zip` nesta pasta é o pacote completo (`.env`
com o endereço preenchido, `COMECE-AQUI.txt`, `data/` protegido). Baixe a versão
publicada em
[`php/downloads/`](https://github.com/EdijalmeMoura/SOCIALMEDIA-IA/tree/arena/4b255bc3-socialmedia-ia/php/downloads)
ou gere um novo a qualquer momento:

```sh
git archive --format=zip -o socialai-php.zip HEAD:php
```

O pacote publicado **não contém segredos**: preencha `SECRET_KEY` e
`SOCIALMEDIA_INSTALL_TOKEN` no `.env` antes de enviar (instruções no
`COMECE-AQUI.txt`).

## Por que existe

O endereço `https://projetoredesnordeste.com.br/edijalmemoura/socialai/`
respondia `403` porque a pasta não tinha aplicação PHP/Python atendendo. PHP é
nativo no cPanel: nenhum processo extra, nenhum `.htaccess` de CGI, nenhuma
dependência para instalar.

## Instalação no cPanel (3 minutos)

1. Envie o conteúdo desta pasta (`php/`) para `~/socialai-php` — **fora** de
   `public_html` — e aponte o domínio/subpasta para `~/socialai-php/public`.

   Se preferir o caminho tradicional do cPanel, envie a pasta inteira para
   `~/public_html/edijalmemoura/socialai/`. O `.htaccess` da raiz do projeto
   (versionado) manda tudo para `public/` e bloqueia `.env`, `data/`, `app/`
   e `tests/`, então nada fica exposto nem precisa ser configurado à mão.

2. Copie `.env.example` para `.env` e ajuste:

   ```sh
   SOCIALMEDIA_BASE_PATH=/edijalmemoura/socialai
   SECRET_KEY=<php -r "echo bin2hex(random_bytes(32));">
   SOCIALMEDIA_INSTALL_TOKEN=<invente um token>
   COOKIE_SECURE=1
   ```

3. Permissões: `chmod 600 .env` e `chmod 755 data` (o app cria
   `data/socialmedia.sqlite` e `data/installer.env` com 0600).

4. Abra `https://seu-dominio/edijalmemoura/socialai/` → redireciona para
   `/install`. Com token configurado, use
   `.../socialai/install?access_token=SEU_TOKEN`.

5. Conclua o assistente. O instalador **se fecha** (`410`) e você entra por
   `/login` com o e-mail e a senha cadastrados.

### Alternativa: sem rewrite na raiz

Se o servidor não honrar o `.htaccess` da raiz (raro no cPanel), crie
`public_html/edijalmemoura/socialai/index.php` apenas com:

```php
<?php require __DIR__ . '/public/index.php';
```

O `SOCIALMEDIA_BASE_PATH` continua mandando no prefixo das URLs.

## Estrutura

```
php/
├── public/            ← única pasta exposta pelo servidor
│   ├── index.php      ← front controller
│   ├── .htaccess      ← rewrite portátil (RewriteBase /)
│   └── assets/        ← CSS/JS compartilhados com a versão Python
├── app/
│   ├── Application.php      ← monta rotas, banco, sessão
│   ├── Http/                ← Request, Response, Router
│   ├── Support/             ← Config, EnvFile, Session, View, Upload, Modules
│   ├── Database/            ← conexão SQLite + esquema versionado
│   ├── Installer/           ← regras de instalação (espelham o Python)
│   ├── Auth/                ← login, trava de tentativas, rehash
│   ├── Clients/             ← regras dos clientes (multi-tenant, cores, arquivos)
│   ├── Controllers/         ← instalador, autenticação, dashboard, clientes
│   └── views/               ← templates PHP com escape obrigatório
├── .htaccess          ← raiz: manda para public/ e bloqueia app/, data/, tests/
├── data/              ← SQLite, .env gerado e rascunhos (conteúdo ignorado no Git;
│                        o .htaccess que nega acesso é versionado)
└── tests/             ← suíte que roda em PHP 8.3 real (php-wasm)
```

## Módulos

### Clientes (pronto)

Portfólio de marcas do workspace, com o mesmo modelo de dados da versão Python.

| Rota | Método | O que faz | Quem pode |
|---|---|---|---|
| `/clients` | GET | grade de clientes com busca instantânea | todos |
| `/clients/new` | GET/POST | cadastro (negócio + canais) | owner, admin, editor |
| `/clients/{id}` | GET/POST | perfil: dados, identidade visual, referências | ver: todos · editar: owner/admin/editor |
| `/clients/{id}/delete` | POST | exclui cliente, logo e referências | owner, admin |
| `/clients/{id}/logo` | POST | envia/substitui o logotipo | owner, admin, editor |
| `/clients/{id}/assets` | POST | adiciona imagem de referência | owner, admin, editor |
| `/clients/{id}/assets/{a}/delete` | POST | remove uma referência | owner, admin, editor |
| `/clients/file?file=…` | GET | serve logo/referência **só da própria empresa** | todos |

Regras que valem a pena saber:

- Toda consulta filtra por `company_id`: id de outro workspace responde 404,
  sem revelar que existe.
- Cores aceitam apenas `#rrggbb`; valor inválido cai no padrão da marca
  (`#3158d8`, `#f57a45`, `#16a68a`).
- Upload aceita PNG/JPG/WEBP até 8 MB e valida a **assinatura dos bytes** —
  renomear um `.php` para `.png` não passa. O nome salvo é gerado pelo sistema.
- Excluir o cliente remove em cascata identidade visual e referências, e apaga
  os arquivos do disco.
- Cada escrita (criar, editar, excluir, upload) deixa evento no `audit_log`,
  visível no dashboard.

### Planejamento (pronto)

Calendário editorial por cliente: a IA lê o perfil e a identidade visual da marca
e devolve as publicações do período, com tema, objetivo, legenda, CTA e briefing
visual.

| Rota | Método | O que faz | Quem pode |
|---|---|---|---|
| `/planner` | GET | formulário de geração + lista de calendários | todos |
| `/planner/generate` | POST | cria o calendário (IA ou rascunho local) | owner, admin, editor |
| `/planner/{id}` | GET | calendário: fatos, grade semanal e publicações | todos |
| `/planner/{id}/production` | POST | envia plano e publicações para produção | owner, admin, editor |
| `/planner/{id}/delete` | POST | exclui o calendário e as publicações | owner, admin |
| `/planner/posts/{id}/edit` | GET/POST | edita uma publicação | ver: todos · editar: owner/admin/editor |
| `/planner/posts/{id}/duplicate` | POST | duplica a publicação ao fim do plano | owner, admin, editor |
| `/planner/posts/{id}/delete` | POST | remove a publicação | owner, admin, editor |

Regras que valem a pena saber:

- **Sem `OPENAI_API_KEY` o planejamento continua funcionando**: ele cria um
  *rascunho local* marcado como tal (`ai_model = local-draft`, 0 tokens) e a tela
  diz "Rascunho local (sem IA)". O produto nunca apresenta texto de template como
  se fosse IA.
- Com chave, a chamada usa o mesmo contrato da versão Python (JSON com os 11
  campos por post, `temperature 0.7`, `max_tokens 10000`) e o consumo fica em
  `ai_generations`. `OPENAI_ENDPOINT` permite apontar para Azure ou um proxy.
- **Nada entra no banco sem validação**: quantidade exata de posts, datas dentro
  do período (inclusivo), redes apenas as escolhidas, campos essenciais
  preenchidos. Resposta fora disso vira mensagem tratada, nunca erro 500.
- A quantidade de publicações é limitada a 45 por período (7, 15 ou 30 dias).
- O conteúdo gerado é tratado como **não confiável** e escapado na tela.
- Toda consulta filtra por `company_id`: calendário de outra agência responde 404.
- Excluir o calendário remove as publicações em cascata; duplicar soma 1 ao alvo
  do plano, remover subtrai 1 (nunca abaixo de zero).
- Escritas deixam evento no `audit_log` (`planner.created`, `planner.production`,
  `planner.deleted`).

### Estúdio (pronto)

Um assunto vira arte pronta: texto, imagem de fundo, ajuste na prancheta e
arquivo final para publicar.

| Rota | Método | O que faz | Quem pode |
|---|---|---|---|
| `/studio` | GET | formulário de criação + galeria de artes | todos |
| `/studio/generate` | POST | cria a arte (IA ou rascunho local) | owner, admin, editor |
| `/studio/posts/{id}` | GET | editor com prancheta, controles e versões | todos |
| `/studio/posts/{id}/save` | POST | salva texto, layout e cor numa nova versão | owner, admin, editor |
| `/studio/posts/{id}/image` | POST | gera a imagem de fundo com IA | owner, admin, editor |
| `/studio/posts/{id}/image/upload` | POST | envia sua imagem (ajustada ao formato) | owner, admin, editor |
| `/studio/posts/{id}/export` | POST | recebe o PNG/JPG renderizado e libera o download | owner, admin, editor |
| `/studio/posts/{id}/download` | GET | baixa a arte exportada | todos |
| `/studio/posts/{id}/variation` | POST | cria uma versão criativa alternativa | owner, admin, editor |
| `/studio/posts/{id}/versions/{v}/restore` | POST | restaura uma versão anterior | owner, admin, editor |
| `/studio/posts/{id}/delete` | POST | exclui a arte, as versões e os arquivos | owner, admin, editor |
| `/studio/files?file=…` | GET | serve imagem/exportação **só da própria empresa** | todos |

Sete formatos com as mesmas medidas do produto Python: post quadrado (1080×1080),
post vertical e anúncio (1080×1350), stories (1080×1920), carrossel (1080×1350),
banner (1200×628) e capa (1640×624).

Regras que valem a pena saber:

- **A prancheta desenha no navegador**, não no servidor: título, subtítulo, CTA e
  assinatura da marca seguem um layout JSON validado no PHP (quatro elementos,
  coordenadas dentro do canvas, cores `#rrggbb`). Sem biblioteca gráfica no
  servidor — funciona em qualquer cPanel.
- A exportação manda o PNG/JPG renderizado de volta ao PHP, que confere a
  assinatura dos bytes, grava o arquivo e libera o download nomeado
  (`socialmedia-ia-{id}.png`).
- **Sem `OPENAI_API_KEY`** o estúdio cria um *rascunho local* marcado como tal e
  deixa o botão de imagem desabilitado; enviar a própria imagem funciona.
- Com chave: texto pelo Chat Completions e imagem pelo endpoint de imagens
  (`OPENAI_IMAGE_MODEL`, padrão `gpt-image-1`). O consumo entra em
  `ai_generations` (`studio_copy`, `studio_image`, `studio_variation`).
- **Cada ação vira versão**: gerar, editar, trocar imagem, exportar e restaurar
  guardam uma cópia do estado — dá para voltar atrás sem perder trabalho.
- A imagem é sempre reenquadrada para o formato (cobre e corta o excesso,
  centralizada) e validada pela assinatura dos bytes; limite de 8 MB.
- Conteúdo da IA é entrada não confiável: escapado na tela e limitado no layout.
- Isolamento por `company_id` em tudo, inclusive no arquivo servido; a exclusão
  remove arte, versões em cascata e os arquivos do disco.

### Aprovações (pronto)

O conteúdo sai da agência, é revisado pelo cliente e volta com histórico. Cada
envio é uma **fotografia**: o que o cliente aprovou continua sendo exatamente
aquilo, mesmo que a arte mude depois no estúdio.

**Agencia** (menu lateral → Aprovações):

| Rota | Método | O que faz | Quem pode |
|---|---|---|---|
| `/approvals` | GET | fila de revisões, conteúdos disponíveis e acessos do portal | todos |
| `/approvals` | POST | envia arte exportada ou pauta para o cliente | owner, admin, editor |
| `/approvals/{id}` | GET | fotografia enviada + histórico + comentários | todos |
| `/approvals/{id}/comment` | POST | comenta (com imagem opcional) e avisa o cliente | owner, admin, editor |
| `/approvals/{id}/cancel` | POST | cancela a revisão e libera o conteúdo | owner, admin, editor |
| `/approvals/{id}/media/{arquivo}` | GET | serve a arte ou um anexo **daquela revisão** | todos |
| `/approvals/portal-users` | POST | cria acesso do cliente ao portal | owner, admin |
| `/approvals/portal-users/{id}/toggle` | POST | pausa/reativa o acesso | owner, admin |
| `/approvals/notifications/read` | POST | marca os avisos da equipe como lidos | todos |

**Portal do cliente** (endereço separado, `/portal`):

| Rota | Método | O que faz |
|---|---|---|
| `/portal/login` | GET/POST | entrada do cliente (e-mail e senha próprios) |
| `/portal/logout` | POST | sai do portal |
| `/portal/approvals` | GET | meus conteúdos, pendentes primeiro |
| `/portal/approvals/{id}` | GET | conteúdo aberto, histórico e comentários |
| `/portal/approvals/{id}/respond` | POST | aprova, pede alterações ou rejeita |
| `/portal/approvals/{id}/comment` | POST | comenta (com imagem opcional) |
| `/portal/approvals/{id}/media/{arquivo}` | GET | vê a arte e os anexos da revisão |
| `/portal/notifications/read` | POST | marca os avisos do cliente como lidos |

Regras que valem a pena saber:

- **Fotografia, não link vivo**: no envio, o conteúdo é congelado em
  `approvals.snapshot_json` (arte: formato, medidas, texto, imagem e arquivo
  exportado; pauta: rede, data, objetivo, texto, legenda, CTA e briefing). O
  cliente revisa o que foi enviado, não o que o estúdio tem agora.
- **Uma pendência por conteúdo**, garantida por índice único parcial: dois
  cliques ao mesmo tempo não criam duas revisões. Enviar de novo um conteúdo já
  pendente responde com "Este conteúdo já está aguardando aprovação."
- **Ciclos**: responder encerra o ciclo; um novo envio cria o ciclo 2, 3… com o
  histórico anterior intacto (é o que torna a revisão auditável).
- Só entra em revisão **arte exportada** (`status='exported'` com arquivo) ou
  pauta do planejamento. Rascunho do estúdio não aparece na lista.
- O cliente decide **uma vez**: responder de novo devolve **409** em vez de
  sobrescrever. Pedir alterações exige texto ou imagem anexada.
- **Sessões separadas**: o portal usa `portal_user_id`, o painel usa `user_id`.
  Entrar como cliente não abre a agência; entrar na agência encerra a sessão do
  portal no mesmo navegador. Desativar a conta derruba o acesso na hora, mesmo
  com a sessão aberta.
- **Avisos dentro do produto** (não por e-mail, que cPanel compartilhado não
  entrega): a equipe recebe "Retorno do cliente" e "Novo comentário do cliente";
  o cliente recebe "Novo conteúdo para revisão" e "Novo comentário da agência".
- Entrada do portal tem trava de **10 tentativas por 5 minutos**; a mensagem é
  sempre a mesma para e-mail inexistente e senha errada.
- Mídia só é servida se o arquivo estiver na fotografia daquela revisão ou for
  anexo de um comentário dela, sempre no escopo da empresa (agência) ou da
  empresa + cliente (portal), com `Cache-Control: private, no-store`.
- Escritas deixam evento em `approval_events` e rastro em `audit_log`
  (`approval.sent`, `approval.cancelled`, `portal.user_created`).

O cliente entra por `https://seu-dominio/.../socialai/portal/login` — mande esse
endereço junto com o e-mail e a senha temporária. Ele nunca vê o painel da
agência, nem outros clientes.

### Feed (pronto)

A grade 3×3 do Instagram montada com o que a agência já produziu — para ver a
sequência como o seguidor veria antes de mandar para aprovação.

| Rota | Método | O que faz | Quem pode |
|---|---|---|---|
| `/feed` | GET | perfil da marca, grade 3×3 e fontes fora da grade | todos |
| `/feed/{cliente}/add/creative/{arte}` | POST | coloca uma arte do estúdio no fim da grade | owner, admin, editor |
| `/feed/{cliente}/add/post/{pauta}` | POST | coloca uma pauta do planejamento no fim da grade | owner, admin, editor |
| `/feed/{cliente}/remove/{item}` | POST | tira o item da prévia (o conteúdo original fica) | owner, admin, editor |
| `/feed/{cliente}/reorder` | POST | grava a nova ordem (JSON `{"order":[ids]}`) | owner, admin, editor |

Regras que valem a pena saber:

- **É prévia, não agenda**: nada é publicado nem agendado. Datas editoriais são
  recomendação e o rodapé da tela diz isso explicitamente.
- A ordem é sua, não da data: cada item tem `position`, refeita a cada
  reorganização. Arrastar só muda a tela; gravar é um clique em "Salvar ordem".
- **Reordenar é tudo ou nada**: a lista enviada precisa ser exatamente a lista
  atual. Se outra aba adicionou/removeu algo, a resposta é **409** com "atualize
  a página" — nunca embaralha o que outra pessoa mexeu.
- Arte e pauta convivem na mesma grade com o mesmo formato: arte mostra a imagem
  exportada (ou o rascunho com selo), pauta mostra tema, rede e briefing no bloco
  de texto.
- **Excluir a origem remove o item** (cascata): a prévia nunca aponta para um
  arquivo que não existe mais. Remover da grade, por outro lado, não exclui o
  conteúdo — ele volta para a lista de fontes.
- O mesmo conteúdo não entra duas vezes (índice único por arte/pauta na grade),
  nem em marcas diferentes: a checagem é por empresa + cliente.
- Escritas deixam rastro em `audit_log` (`feed.added`, `feed.removed`,
  `feed.reordered`).

### Relatórios (pronto)

O que a agência **fez** no período, contado a partir dos registros do próprio
produto — e nada além disso.

| Rota | Método | O que faz | Quem pode |
|---|---|---|---|
| `/reports` | GET | recorte por período, números do mês, quebras e registros | todos |
| `/reports/export.csv` | GET | o mesmo recorte em CSV para planilha | todos |

Parâmetros (todos opcionais): `start_date`, `end_date` (AAAA-MM-DD) e
`client_id`.

Regras que valem a pena saber:

- **Não existe métrica de rede aqui.** Alcance, curtidas, impressões e cliques
  só viriam de API de rede social; sem isso, o relatório não mostra — e a tela
  diz isso em um aviso fixo. Um número honesto a menos vale mais que um gráfico
  inventado.
- O recorte é por **data de registro** em UTC (quando o item entrou no produto),
  não pela data editorial da pauta. O padrão é do dia 1º do mês até hoje.
- Período máximo de **366 dias**. `fim` antes de `início` é recusado.
- Recorte inválido **não derruba a tela**: a página volta ao padrão com um aviso
  âmbar. No CSV, o mesmo recorte inválido responde **400** com o motivo em texto
  puro — planilha não deve receber um arquivo pela metade.
- `client_id` de outra empresa → **404** (a marca nem existe para você). Id
  malformado volta com "Escolha um cliente válido." e o relatório completo.
- A lista de registros mostra os **300 mais recentes** e avisa quando cortou; o
  CSV tem o mesmo limite, para tela e planilha contarem a mesma história.
- O CSV sai com `;` (padrão do Excel em português), BOM UTF-8 e apóstrofo antes
  de `=`, `+`, `-`, `@`, tabulação e retorno de carro: texto vindo do banco nunca
  vira fórmula na sua planilha.
- Dois painéis só existem aqui: **Consumo de IA** (`ai_generations` — chamadas,
  modelo e tokens por recurso; rascunho local aparece como `local-draft` com
  zero token) e o card **Na prévia do feed** (`feed_items`).
- Relatório é leitura: **nenhuma tabela nova**, nenhuma auditoria, nenhum dado
  alterado. A versão do esquema continua a mesma do feed (5).

### Próximos

Meta. Cada módulo entra por migração aditiva do `Schema` (versão 2 = clientes,
3 = planejamento, 4 = estúdio, 5 = aprovações — o feed usa a tabela `feed_items`
já criada no 3, e os relatórios não criam tabela), então atualizar o pacote
nunca apaga dados de uma instalação em uso.

## Subpasta: como é resolvido

O `Request::resolvePaths()` cobre os casos que aparecem em cPanel:

| Servidor entrega | Resultado |
| --- | --- |
| `REQUEST_URI=/edijalmemoura/socialai/install` | prefixo `/edijalmemoura/socialai`, rota `/install` |
| `SCRIPT_NAME=/.../index.php` + `PATH_INFO=/install` | usa o `PATH_INFO` |
| Só `PATH_INFO=/install` | usa o prefixo do script |
| `SOCIALMEDIA_BASE_PATH` declarado | tem prioridade sobre a detecção |

Com isso, `url()`, o cookie de sessão, o CSRF e os redirecionamentos saem
sempre com o prefixo — inclusive quando o servidor não anuncia nada.

## Testes

A suíte roda **PHP 8.3 de verdade** (WebAssembly), sem precisar de PHP
instalado na máquina:

```sh
cd php
npm install        # @php-wasm/universal + @php-wasm/node (só para testes)
npm test           # parse de todos os arquivos + 725 verificações funcionais
```

Cobre: normalização de subpasta, `.env`, detecção de caminho, token do
instalador, CSRF, validação de formulário, regras de URL pública (com
subpasta e rejeições), instalação completa, hash da senha, permissão 0600 do
arquivo de segredos, login, logout, dashboard, 404/405, isolamento entre
instâncias e o módulo de clientes (cadastro, edição, cores, upload validado
por assinatura, permissões por papel, exclusão em cascata), planejamento, estúdio
e aprovações (envio com fotografia, ciclos, decisão do cliente, 409 em resposta
dupla, anexos, contas do portal, sessões separadas, mídia restrita, migração
aditiva sobre banco antigo), feed (grade 3×3, fontes, arrastar com 409 quando a
lista muda, remoção sem excluir o original, cascata ao excluir a arte) e
relatórios (recorte de período com limite de 366 dias, contagem por registro,
isolamento por empresa, CSV com BOM e proteção contra fórmula, limite de 300
linhas e migração sem tabela nova).

Para exercitar o caminho HTTP completo (cookies, redirecionamentos, HTML):

```sh
node tests/serve.mjs 8099 /edijalmemoura/socialai
```

## Dados e backup

| Arquivo | Permissão | Backup |
| --- | --- | --- |
| `data/socialmedia.sqlite` | 0600 | sim (contém tudo) |
| `data/installer.env` | 0600 | sim (SECRET_KEY e segredos) |
| `.env` | 0600 | sim |

Sem `SECRET_KEY` persistente a sessão não sobrevive a reinícios; sem
`META_TOKEN_ENCRYPTION_KEY` os tokens da Meta ficam ilegíveis. Guarde os dois.

## Diferenças em relação à versão Python (por enquanto)

- Módulos de negócio ainda não portados (aparecem como "EM BREVE" no painel).
- Instalação automática por variáveis (`SOCIALMEDIA_AUTO_INSTALL`) entra junto
  com o módulo de configurações.
- O `requirements.txt`/Docker continuam válidos para a versão Python, que
  permanece na raiz do repositório e não foi alterada.
